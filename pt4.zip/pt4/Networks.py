import torch
import torch.nn as nn
import torch.nn.functional as F

class Action_Conditioned_FF(nn.Module):
    def __init__(self, input_size=6, hidden_size=16, output_size=1):
        super(Action_Conditioned_FF, self).__init__()
        # Initialize layers for the network
        self.fc1 = nn.Linear(input_size, hidden_size)  # First hidden layer
        self.fc2 = nn.Linear(hidden_size, hidden_size)  # Second hidden layer
        self.fc3 = nn.Linear(hidden_size, output_size)  # Output layer

    def forward(self, input):
        # Define the forward pass through the network
        x = F.relu(self.fc1(input))
        x = F.relu(self.fc2(x))
        output = torch.sigmoid(self.fc3(x))  # Sigmoid activation for binary classification
        return output

    def evaluate(self, model, test_loader, loss_function):
        model.eval()  # Set model to evaluation mode
        total_loss = 0.0
        with torch.no_grad():  # Disable gradient computation for evaluation
            for sample in test_loader:
                inputs = sample['input']
                labels = sample['label']
                outputs = model(inputs)
                loss = loss_function(outputs, labels.unsqueeze(1))
                total_loss += loss.item()
        
        # Calculate the average loss
        average_loss = total_loss / len(test_loader)
        return average_loss

def main():
    model = Action_Conditioned_FF()
    print("Model initialized and ready for training/evaluation.")

if __name__ == '__main__':
    main()
