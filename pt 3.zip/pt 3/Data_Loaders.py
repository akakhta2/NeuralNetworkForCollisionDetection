import torch
import torch.utils.data as data
import torch.utils.data.dataset as dataset
import numpy as np
import pickle
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split

class Nav_Dataset(dataset.Dataset):
    def __init__(self):
        # Load the data from CSV
        self.data = np.genfromtxt('saved/training_data.csv', delimiter=',')
        
        # Normalize data and save scaler for inference
        self.scaler = MinMaxScaler()
        self.normalized_data = self.scaler.fit_transform(self.data)  # fits and transforms
        pickle.dump(self.scaler, open("saved/scaler.pkl", "wb"))  # save to normalize at inference

    def __len__(self):
        # Return the length of the dataset
        return len(self.normalized_data)

    def __getitem__(self, idx):
        if not isinstance(idx, int):
            idx = idx.item()
        
        # Separate features and label
        x = self.normalized_data[idx, :-1]  # All columns except the last
        y = self.normalized_data[idx, -1]   # Last column is the label
        
        # Return as a dictionary with 'input' and 'label' keys
        return {'input': torch.tensor(x, dtype=torch.float32), 'label': torch.tensor(y, dtype=torch.float32)}

class Data_Loaders():
    def __init__(self, batch_size):
        # Load and split data
        dataset = Nav_Dataset()
        train_indices, test_indices = train_test_split(range(len(dataset)), test_size=0.2, random_state=42)
        
        # Subset datasets
        train_data = data.Subset(dataset, train_indices)
        test_data = data.Subset(dataset, test_indices)

        # Initialize data loaders
        self.train_loader = data.DataLoader(train_data, batch_size=batch_size, shuffle=True)
        self.test_loader = data.DataLoader(test_data, batch_size=batch_size, shuffle=False)

def main():
    batch_size = 16
    data_loaders = Data_Loaders(batch_size)
    
    # Test iteration over train and test loaders
    for idx, sample in enumerate(data_loaders.train_loader):
        _, _ = sample['input'], sample['label']
    for idx, sample in enumerate(data_loaders.test_loader):
        _, _ = sample['input'], sample['label']

if __name__ == '__main__':
    main()
